from django.contrib import admin
from .models import Profile, KYCApplication, Transaction, ActivityLog

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'full_name', 'phone', 'wallet_address')
    search_fields = ('user__username', 'full_name', 'phone')

@admin.register(KYCApplication)
class KYCApplicationAdmin(admin.ModelAdmin):
    list_display = ('user', 'document_type', 'status', 'submitted_at')
    list_filter = ('status', 'document_type')
    search_fields = ('user__username', 'id_number', 'wallet_address')
    readonly_fields = ('submitted_at',)
    actions = ['mark_verified', 'mark_rejected']

    def mark_verified(self, request, queryset):
        updated = queryset.update(status=KYCApplication.STATUS_VERIFIED)
        self.message_user(request, f"{updated} application(s) marked as verified.")
    mark_verified.short_description = "Mark selected as verified"

    def mark_rejected(self, request, queryset):
        updated = queryset.update(status=KYCApplication.STATUS_REJECTED)
        self.message_user(request, f"{updated} application(s) marked as rejected.")
    mark_rejected.short_description = "Mark selected as rejected"


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('tx_ref', 'user', 'tx_type', 'amount', 'status', 'created_at')
    search_fields = ('tx_ref', 'user__username')


@admin.register(ActivityLog)
class ActivityLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'action', 'ip_address', 'created_at')
    search_fields = ('user__username', 'ip_address')
    list_filter = ('action',)
