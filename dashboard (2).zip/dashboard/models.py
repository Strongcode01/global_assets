from django.db import models
from django.conf import settings
from django.contrib.auth.models import User
from django.utils import timezone

class Profile(models.Model):
    """Extended user profile used by account.html and KYC forms."""
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    full_name = models.CharField(max_length=255, blank=True)
    surname = models.CharField(max_length=255, blank=True)
    phone = models.CharField(max_length=50, blank=True)
    dob = models.DateField(null=True, blank=True)
    nationality = models.CharField(max_length=100, blank=True)
    address_line1 = models.CharField(max_length=255, blank=True)
    address_line2 = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=128, blank=True)
    zip_code = models.CharField(max_length=30, blank=True)
    telegram = models.CharField(max_length=100, blank=True)
    wallet_address = models.CharField(max_length=250, blank=True)
    wallet_type = models.CharField(max_length=50, blank=True)
    # notification settings stored as booleans
    notify_resume_sales = models.BooleanField(default=False)
    notify_latest_news = models.BooleanField(default=True)
    notify_unusual_activity = models.BooleanField(default=True)

    def __str__(self):
        return f"Profile({self.user.username})"

class KYCApplication(models.Model):
    DOC_PASSPORT = 'passport'
    DOC_NATIONAL_ID = 'national_id'
    DOC_DRIVERS = 'drivers_license'
    DOC_CHOICES = [
        (DOC_PASSPORT, 'Passport'),
        (DOC_NATIONAL_ID, 'National Card'),
        (DOC_DRIVERS, 'Driver\'s License'),
    ]

    STATUS_NOT_SUBMITTED = 'not_submitted'
    STATUS_PENDING = 'pending'
    STATUS_VERIFIED = 'verified'
    STATUS_REJECTED = 'rejected'
    STATUS_INCOMPLETE = 'incomplete'
    STATUS_CHOICES = [
        (STATUS_NOT_SUBMITTED, 'Not submitted'),
        (STATUS_PENDING, 'Pending'),
        (STATUS_VERIFIED, 'Verified'),
        (STATUS_REJECTED, 'Rejected'),
        (STATUS_INCOMPLETE, 'Incomplete'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="kyc_applications")
    full_name = models.CharField(max_length=255)
    id_number = models.CharField(max_length=255, blank=True)
    document_type = models.CharField(max_length=50, choices=DOC_CHOICES, default=DOC_PASSPORT)
    passport_file = models.FileField(upload_to='kyc/passport/', null=True, blank=True)
    id_front_file = models.FileField(upload_to='kyc/id_front/', null=True, blank=True)
    id_back_file = models.FileField(upload_to='kyc/id_back/', null=True, blank=True)
    drivers_file = models.FileField(upload_to='kyc/drivers/', null=True, blank=True)
    wallet_address = models.CharField(max_length=255, blank=True)
    wallet_type = models.CharField(max_length=50, blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=40, choices=STATUS_CHOICES, default=STATUS_PENDING)
    admin_note = models.TextField(blank=True)

    class Meta:
        ordering = ['-submitted_at']

    def __str__(self):
        return f"KYC({self.user.username} - {self.document_type} - {self.status})"

class Transaction(models.Model):
    TX_CREDIT = 'credit'
    TX_DEBIT = 'debit'
    TX_CHOICES = [(TX_CREDIT, 'Credit'), (TX_DEBIT, 'Debit')]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='transactions')
    tx_ref = models.CharField(max_length=64, blank=True)
    amount = models.DecimalField(max_digits=16, decimal_places=8)
    description = models.TextField(blank=True)
    tx_type = models.CharField(max_length=10, choices=TX_CHOICES, default=TX_DEBIT)
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=30, default='pending')

    def __str__(self):
        return f"{self.tx_type} {self.amount} ({self.user.username})"

class ActivityLog(models.Model):
    """Basic activity log for user's account (login, ip, device)."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='activity_logs')
    action = models.CharField(max_length=100)  # e.g. "login", "password_change"
    ip_address = models.CharField(max_length=45, blank=True)
    device = models.CharField(max_length=255, blank=True)
    browser = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} - {self.action} @ {self.created_at}"
