from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    path('', views.index, name='index'),
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    path('account/', views.account_view, name='account'),
    path('activity/', views.activity_view, name='activity'),

    path('kyc-application/', views.kyc_application_view, name='kyc_application'),
    path('kyc-status/', views.kyc_status_view, name='kyc_status'),
    path('kyc/', views.kyc_application_view, name='kyc'),  # alias

    path('transactions/', views.transactions_view, name='transactions'),
    path('transactions/create/', views.create_transaction, name='create_transaction'),

    path('faq/', views.faq_view, name='faq'),
    path('how-to/', views.how_to_view, name='how_to'),
]
