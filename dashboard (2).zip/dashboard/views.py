from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse
from .forms import SignupForm, LoginForm, ProfileForm, KYCApplicationForm, TransactionForm
from .models import Profile, KYCApplication, Transaction, ActivityLog
from django.contrib.auth.models import User
from django.db import transaction as db_transaction
from django.core.paginator import Paginator
from django.contrib.auth import get_user_model
from dashboard import models

User = get_user_model()

def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            # create empty profile
            Profile.objects.get_or_create(user=user)
            messages.success(request, "Account created. Please login.")
            return redirect('dashboard:login')
    else:
        form = SignupForm()
    return render(request, 'dashboard/signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request=request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            # log activity
            ActivityLog.objects.create(
                user=user,
                action='login',
                ip_address=request.META.get('REMOTE_ADDR', ''),
                device=request.META.get('HTTP_USER_AGENT', '')[:255],
                browser=''  # you can parse UA if desired
            )
            return redirect('dashboard:index')
        else:
            messages.error(request, "Invalid credentials")
    else:
        form = LoginForm()
    return render(request, 'dashboard/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('dashboard:login')

@login_required
def index(request):
    # Dashboard overview using your templates/index.html
    profile, _ = Profile.objects.get_or_create(user=request.user)
    # sample token balance - we use sum of credit transactions minus debit
    credits = Transaction.objects.filter(user=request.user, tx_type=Transaction.TX_CREDIT).aggregate_total = Transaction.objects.filter(user=request.user, tx_type='credit').aggregate_total = None
    # instead compute totals simply:
    total_credit = Transaction.objects.filter(user=request.user, tx_type='credit').aggregate(models.Sum('amount'))['amount__sum'] or 0
    total_debit = Transaction.objects.filter(user=request.user, tx_type='debit').aggregate(models.Sum('amount'))['amount__sum'] or 0
    balance = total_credit - total_debit
    recent_transactions = Transaction.objects.filter(user=request.user).order_by('-created_at')[:8]
    context = {
        'profile': profile,
        'balance': balance,
        'recent_transactions': recent_transactions,
    }
    return render(request, 'dashboard/index.html', context)

@login_required
def account_view(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated.")
            return redirect('dashboard:account')
    else:
        form = ProfileForm(instance=profile)
    return render(request, 'dashboard/account.html', {'form': form, 'profile': profile})

@login_required
def activity_view(request):
    logs = ActivityLog.objects.filter(user=request.user)
    # paginate
    paginator = Paginator(logs, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'dashboard/activity.html', {'page_obj': page_obj})

@login_required
def kyc_application_view(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)
    # If user already has a KYC in pending state show it
    latest = KYCApplication.objects.filter(user=request.user).first()
    if request.method == 'POST':
        form = KYCApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            app = form.save(commit=False)
            app.user = request.user
            app.save()
            messages.success(request, "KYC submitted. We'll review and notify you.")
            return redirect('dashboard:kyc_status')
    else:
        form = KYCApplicationForm(initial={
            'full_name': profile.full_name or request.user.get_full_name(),
            'wallet_address': profile.wallet_address,
            'wallet_type': profile.wallet_type,
        })
    return render(request, 'dashboard/kyc-application.html', {'form': form, 'application': latest})

@login_required
def kyc_status_view(request):
    latest = KYCApplication.objects.filter(user=request.user).first()
    return render(request, 'dashboard/kyc-status.html', {'application': latest})

@login_required
def transactions_view(request):
    txs = Transaction.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'dashboard/transactions.html', {'transactions': txs})

@login_required
def create_transaction(request):
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            tx = form.save(commit=False)
            tx.user = request.user
            tx.save()
            messages.success(request, "Transaction created.")
            return redirect('dashboard:transactions')
    else:
        form = TransactionForm()
    return render(request, 'dashboard/tokens.html', {'form': form})


# simple static page views (how-to, faq, etc.)
@login_required
def faq_view(request):
    return render(request, 'dashboard/faq.html')

@login_required
def how_to_view(request):
    return render(request, 'dashboard/how-to.html')