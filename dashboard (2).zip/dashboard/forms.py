from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import get_user_model
from .models import Profile, KYCApplication, Transaction

User = get_user_model()

class SignupForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(required=False)
    last_name = forms.CharField(required=False)

    class Meta:
        model = User
        fields = ("username", "email", "first_name", "last_name", "password1", "password2")

class LoginForm(AuthenticationForm):
    username = forms.CharField(label="Username or email")

class ProfileForm(forms.ModelForm):
    dob = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date'}))
    class Meta:
        model = Profile
        fields = [
            'full_name', 'surname', 'phone', 'dob', 'nationality',
            'address_line1', 'address_line2', 'city', 'zip_code',
            'telegram', 'wallet_address', 'wallet_type'
        ]

class KYCApplicationForm(forms.ModelForm):
    # allow upload of multiple doc fields but only one will be required depending on type
    class Meta:
        model = KYCApplication
        fields = [
            'full_name', 'id_number', 'document_type',
            'passport_file', 'id_front_file', 'id_back_file', 'drivers_file',
            'wallet_address', 'wallet_type'
        ]
    def clean(self):
        cleaned = super().clean()
        doc_type = cleaned.get('document_type')
        # ensure at least one relevant file is uploaded
        if doc_type == KYCApplication.DOC_PASSPORT and not cleaned.get('passport_file'):
            self.add_error('passport_file', 'Passport file is required for passport selection.')
        if doc_type == KYCApplication.DOC_NATIONAL_ID and not (cleaned.get('id_front_file') or cleaned.get('id_back_file')):
            self.add_error('id_front_file', 'ID front/back required for national ID selection.')
        if doc_type == KYCApplication.DOC_DRIVERS and not cleaned.get('drivers_file'):
            self.add_error('drivers_file', 'Driver license copy required.')
        return cleaned

class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['tx_ref', 'amount', 'description', 'tx_type']
